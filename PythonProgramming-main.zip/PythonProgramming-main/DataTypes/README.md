# **Python Variables and Data Types** 
